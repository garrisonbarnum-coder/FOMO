/*
  FOMO background monitor bridge.
  Add this before </body> in index.html:

  <script src="./fomo-background.js"></script>

  It does not replace your live DEX Screener code. It loads the server-side
  snapshot produced by GitHub Actions and emits a browser event.
*/
(() => {
  const SNAPSHOT_URL = "./data/latest.json";
  const CACHE_KEY = "fomo_background_snapshot_v1";

  async function loadBackgroundSnapshot() {
    try {
      const res = await fetch(`${SNAPSHOT_URL}?t=${Date.now()}`, {
        cache: "no-store"
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      localStorage.setItem(CACHE_KEY, JSON.stringify(data));
      window.FOMO_BACKGROUND = data;
      window.dispatchEvent(new CustomEvent("fomo:background-data", { detail: data }));
      return data;
    } catch (err) {
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const data = JSON.parse(cached);
        window.FOMO_BACKGROUND = data;
        window.dispatchEvent(new CustomEvent("fomo:background-data", { detail: data }));
        return data;
      }
      console.warn("FOMO background snapshot unavailable:", err);
      return null;
    }
  }

  window.FOMOBackground = { load: loadBackgroundSnapshot };

  loadBackgroundSnapshot();
  setInterval(loadBackgroundSnapshot, 60 * 1000);
})();
